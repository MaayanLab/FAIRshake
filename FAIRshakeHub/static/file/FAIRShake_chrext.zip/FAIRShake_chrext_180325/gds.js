$("head").append('<style type="text/css">#submithere{ display: none;}</style>');
$("head").append('<style type="text/css">div.tooltip {' +
    'position: absolute;' +
    'padding: 2px;' +
    'font: 13px sans-serif;' +
    'background: black;' +
    'color:white;' +
    'border-radius:2px;' +
    'pointer-events: none;' +
    'max-width: 300px;' +
    '}</style>');

$("head").append('<style type="text/css">#insigform{position:relative; top:0px; left:0px;}</style>')

$(document).ready(function () {

    var theURL = window.location.href;

    var infoTable = $("table[id='gds_details']").eq(0);

    theName = $(infoTable).find("tr[class='caption']").eq(0).text();
    theName = theName.match(/DataSet Record(.*):/).pop();
    alert(theName);

    theDescrip1 = $(infoTable).find("tr:contains(Title:)").find("td").eq(0).text();
    theDescrip2 = $(infoTable).find("tr:contains(Summary:)").find("td").eq(0).text();

    var theQ = jQuery.ajax({
        async: false,
        url: 'http://54.175.203.110/fairshake/api/getQByType?',
        data: {
            'type':'Dataset'
        },
        success: function (data) {
            return data
        }
    }).responseText;
    alert(theQ);

    $.ajax({
        url: 'http://54.175.203.110/fairshake/api/getAvg?',
        data: {
            'url': theURL
        },
        success: function (data) {
            if (data == 'None') {
                makeBlankInsig(theQ);
            } else {
                makeInsig(data, theQ);
            }
        }
    });

    $(infoTable).prepend('<tr><td style="width: 20%;"><strong>FAIRness Assessment:</strong></td><td><div>'
        + '<form action="http://54.175.203.110/fairshake/redirectedFromExt" id="insigform" method="GET" target="_blank">'
        + '<input type="hidden" name="theName" value="' + theName + '">'
        + '<input type="hidden" name="theURL" value="' + theURL + '">'
        + '<input type="hidden" name="theDescrip" value="' + theDescrip + '">'
        + '<input type="hidden" name="theType" value="Dataset">'
        + '<input type="hidden" name="theSrc" value="DataMed">'
        + '<label id="submitlabel"><input type="submit" id="submithere"/></label></form></div></td></tr>');

});

function getSqDimension(qstns){
    sqnum=qstns.length;
    sqDimension=0;
    if(sqnum==4){
        sqDimension=20;
    } else if(sqnum==9){
        sqDimension=13;
    } else if(sqnum==16){
        sqDimension=10;
    } else if(sqnum==25){
        sqDimension=8;
    }
    return sqDimension;
}

function makeInsig(avg, qstns) {

    scale = d3.scaleLinear().domain([-1, 1])
        .interpolate(d3.interpolateRgb)
        .range([d3.rgb(255, 0, 0), d3.rgb(0, 0, 255)]);

    var body = d3.select("#submitlabel").append("svg").attr("width", 40).attr("height", 40);

    body.selectAll("rect.insig").data(getData(avg, qstns)).enter().append("rect").attr("class", "insig")
        .attr("height",getSqDimension(qstns)).attr("width",getSqDimension(qstns))
        .attr("id", function (d, i) {
            return "insigSq-" + (i + 1)
        })
        .attr("x", function (d) {
            return d.posx;
        }).attr("y", function (d) {
        return d.posy;
    }).style("fill", function (d) {
        return scale(d.numdata);
    })
        .style("stroke", "white").style("stroke-width", 1).style("shape-rendering", "crispEdges");

    body.selectAll("rect.btn").data(getData(avg, qstns)).enter().append("rect").attr("class", "btn")
        .attr("height",getSqDimension(qstns)).attr("width",getSqDimension(qstns))
        .attr("x", function (d) {
            return d.posx;
        }).attr("y", function (d) {
        return d.posy;
    }).style("fill-opacity", 0)
        .on("mouseover", opac)
        .on("mouseout", bopac)
    ;
}

function makeBlankInsig(qstns) {
    var body = d3.select("#submitlabel").append("svg").attr("width", 40).attr("height", 40);

    body.selectAll("rect.insig").data(getBlankData(qstns)).enter().append("rect").attr("class", "insig")
        .attr("id", function (d, i) {
            return "insigSq-" + (i + 1)
        })
        .attr("height",getSqDimension(qstns)).attr("width",getSqDimension(qstns))
        .attr("x", function (d) {
            return d.posx;
        }).attr("y", function (d) {
        return d.posy;
    }).style("fill", "darkgray").style("stroke", "white").style("stroke-width", 1).style("shape-rendering", "crispEdges");

    body.selectAll("rect.btn").data(getBlankData(qstns)).enter().append("rect").attr("class", "btn")
        .attr("height",getSqDimension(qstns)).attr("width",getSqDimension(qstns))
        .attr("x", function (d) {
            return d.posx;
        }).attr("y", function (d) {
        return d.posy;
    }).style("fill-opacity", 0)
        .on("mouseover", opacBlank)
        .on("mouseout", bopac)
    ;
}

function getData(avg,qstns) {
    sqnum=qstns.length;

    if (sqnum==4){
        return [{numdata: avg[0], qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {numdata: avg[1], qdata: "2. " + qstns[1], posx: 20, posy: 0},
            {numdata: avg[2], qdata: "3. " + qstns[2], posx: 0, posy: 20},
            {numdata: avg[3], qdata: "4. " + qstns[3], posx: 20, posy: 20}
        ]
    } else if (sqnum==9){
        return [{numdata: avg[0], qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {numdata: avg[1], qdata: "2. " + qstns[1], posx: 13, posy: 0},
            {numdata: avg[2], qdata: "3. " + qstns[2], posx: 26, posy: 0},
            {numdata: avg[3], qdata: "4. " + qstns[3], posx: 0, posy: 13},
            {numdata: avg[4], qdata: "5. " + qstns[4], posx: 13, posy: 13},
            {numdata: avg[5], qdata: "6. " + qstns[5], posx: 26, posy: 13},
            {numdata: avg[6], qdata: "7. " + qstns[6], posx: 0, posy: 26},
            {numdata: avg[7], qdata: "8. " + qstns[7], posx: 13, posy: 26},
            {numdata: avg[8], qdata: "9. " + qstns[8], posx: 26, posy: 26}
        ]
    } else if (sqnum==16){
        return [{numdata: avg[0], qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {numdata: avg[1], qdata: "2. " + qstns[1], posx: 10, posy: 0},
            {numdata: avg[2], qdata: "3. " + qstns[2], posx: 20, posy: 0},
            {numdata: avg[3], qdata: "4. " + qstns[3], posx: 30, posy: 0},
            {numdata: avg[4], qdata: "5. " + qstns[4], posx: 0, posy: 10},
            {numdata: avg[5], qdata: "6. " + qstns[5], posx: 10, posy: 10},
            {numdata: avg[6], qdata: "7. " + qstns[6], posx: 20, posy: 10},
            {numdata: avg[7], qdata: "8. " + qstns[7], posx: 30, posy: 10},
            {numdata: avg[8], qdata: "9. " + qstns[8], posx: 0, posy: 20},
            {numdata: avg[9], qdata: "10. " + qstns[9], posx: 10, posy: 20},
            {numdata: avg[10], qdata: "11. " + qstns[10], posx: 20, posy: 20},
            {numdata: avg[11], qdata: "12. " + qstns[11], posx: 30, posy: 20},
            {numdata: avg[12], qdata: "13. " + qstns[12], posx: 0, posy: 30},
            {numdata: avg[13], qdata: "14. " + qstns[13], posx: 10, posy: 30},
            {numdata: avg[14], qdata: "15. " + qstns[14], posx: 20, posy: 30},
            {numdata: avg[15], qdata: "16. " + qstns[15], posx: 30, posy: 30}
        ]
    } else if (sqnum==25){
        return [{numdata: avg[0], qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {numdata: avg[1], qdata: "2. " + qstns[1], posx: 8, posy: 0},
            {numdata: avg[2], qdata: "3. " + qstns[2], posx: 16, posy: 0},
            {numdata: avg[3], qdata: "4. " + qstns[3], posx: 24, posy: 0},
            {numdata: avg[4], qdata: "5. " + qstns[4], posx: 32, posy: 0},
            {numdata: avg[5], qdata: "6. " + qstns[5], posx: 0, posy: 8},
            {numdata: avg[6], qdata: "7. " + qstns[6], posx: 8, posy: 8},
            {numdata: avg[7], qdata: "8. " + qstns[7], posx: 16, posy: 8},
            {numdata: avg[8], qdata: "9. " + qstns[8], posx: 24, posy: 8},
            {numdata: avg[9], qdata: "10. " + qstns[9], posx: 32, posy: 8},
            {numdata: avg[10], qdata: "11. " + qstns[10], posx: 0, posy: 16},
            {numdata: avg[11], qdata: "12. " + qstns[11], posx: 8, posy: 16},
            {numdata: avg[12], qdata: "13. " + qstns[12], posx: 16, posy: 16},
            {numdata: avg[13], qdata: "14. " + qstns[13], posx: 24, posy: 16},
            {numdata: avg[14], qdata: "15. " + qstns[14], posx: 32, posy: 16},
            {numdata: avg[15], qdata: "16. " + qstns[15], posx: 0, posy: 24},
            {numdata: avg[16], qdata: "17. " + qstns[16], posx: 8, posy: 24},
            {numdata: avg[17], qdata: "18. " + qstns[17], posx: 16, posy: 24},
            {numdata: avg[18], qdata: "19. " + qstns[18], posx: 24, posy: 24},
            {numdata: avg[19], qdata: "20. " + qstns[19], posx: 32, posy: 24},
            {numdata: avg[20], qdata: "21. " + qstns[20], posx: 0, posy: 32},
            {numdata: avg[21], qdata: "22. " + qstns[21], posx: 8, posy: 32},
            {numdata: avg[22], qdata: "23. " + qstns[22], posx: 16, posy: 32},
            {numdata: avg[23], qdata: "24. " + qstns[23], posx: 24, posy: 32},
            {numdata: avg[24], qdata: "25. " + qstns[24], posx: 32, posy: 32},
        ]
    }
}

function getBlankData(qstns) {
    sqnum=qstns.length;

    if (sqnum==4){
        return [{qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {qdata: "2. " + qstns[1], posx: 20, posy: 0},
            {qdata: "3. " + qstns[2], posx: 0, posy: 20},
            {qdata: "4. " + qstns[3], posx: 20, posy: 20}
        ]
    } else if (sqnum==9){
        return [{qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {qdata: "2. " + qstns[1], posx: 13, posy: 0},
            {qdata: "3. " + qstns[2], posx: 26, posy: 0},
            {qdata: "4. " + qstns[3], posx: 0, posy: 13},
            {qdata: "5. " + qstns[4], posx: 13, posy: 13},
            {qdata: "6. " + qstns[5], posx: 26, posy: 13},
            {qdata: "7. " + qstns[6], posx: 0, posy: 26},
            {qdata: "8. " + qstns[7], posx: 13, posy: 26},
            {qdata: "9. " + qstns[8], posx: 26, posy: 26}
        ]
    } else if (sqnum==16){
        return [{qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {qdata: "2. " + qstns[1], posx: 10, posy: 0},
            {qdata: "3. " + qstns[2], posx: 20, posy: 0},
            {qdata: "4. " + qstns[3], posx: 30, posy: 0},
            {qdata: "5. " + qstns[4], posx: 0, posy: 10},
            {qdata: "6. " + qstns[5], posx: 10, posy: 10},
            {qdata: "7. " + qstns[6], posx: 20, posy: 10},
            {qdata: "8. " + qstns[7], posx: 30, posy: 10},
            {qdata: "9. " + qstns[8], posx: 0, posy: 20},
            {qdata: "10. " + qstns[9], posx: 10, posy: 20},
            {qdata: "11. " + qstns[10], posx: 20, posy: 20},
            {qdata: "12. " + qstns[11], posx: 30, posy: 20},
            {qdata: "13. " + qstns[12], posx: 0, posy: 30},
            {qdata: "14. " + qstns[13], posx: 10, posy: 30},
            {qdata: "15. " + qstns[14], posx: 20, posy: 30},
            {qdata: "16. " + qstns[15], posx: 30, posy: 30}
        ]
    } else if (sqnum==25){
        return [{qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {qdata: "2. " + qstns[1], posx: 8, posy: 0},
            {qdata: "3. " + qstns[2], posx: 16, posy: 0},
            {qdata: "4. " + qstns[3], posx: 24, posy: 0},
            {qdata: "5. " + qstns[4], posx: 32, posy: 0},
            {qdata: "6. " + qstns[5], posx: 0, posy: 8},
            {qdata: "7. " + qstns[6], posx: 8, posy: 8},
            {qdata: "8. " + qstns[7], posx: 16, posy: 8},
            {qdata: "9. " + qstns[8], posx: 24, posy: 8},
            {qdata: "10. " + qstns[9], posx: 32, posy: 8},
            {qdata: "11. " + qstns[10], posx: 0, posy: 16},
            {qdata: "12. " + qstns[11], posx: 8, posy: 16},
            {qdata: "13. " + qstns[12], posx: 16, posy: 16},
            {qdata: "14. " + qstns[13], posx: 24, posy: 16},
            {qdata: "15. " + qstns[14], posx: 32, posy: 16},
            {qdata: "16. " + qstns[15], posx: 0, posy: 24},
            {qdata: "17. " + qstns[16], posx: 8, posy: 24},
            {qdata: "18. " + qstns[17], posx: 16, posy: 24},
            {qdata: "19. " + qstns[18], posx: 24, posy: 24},
            {qdata: "20. " + qstns[19], posx: 32, posy: 24},
            {qdata: "21. " + qstns[20], posx: 0, posy: 32},
            {qdata: "22. " + qstns[21], posx: 8, posy: 32},
            {qdata: "23. " + qstns[22], posx: 16, posy: 32},
            {qdata: "24. " + qstns[23], posx: 24, posy: 32},
            {qdata: "25. " + qstns[24], posx: 32, posy: 32},
        ]
    }
}


function roundTwo(num) {
    return +(Math.round(num + "e+2") + "e-2");
}

function opac(d, i) {
    d3.select("#insigSq-" + (i + 1)).style("fill-opacity", .3);
    var div = d3.select('body').append("div")
        .attr("class", "tooltip").attr("id","fairtt").style("opacity", 0);

    div.transition().style("opacity", .8);
    div.html("Score: " + roundTwo(d.numdata) + "<br>" + d.qdata)
        .style("left", (d3.event.pageX + 10) + "px")
        .style("top", (d3.event.pageY - 28) + "px");
}

function opacBlank(d, i) {
    d3.select("#insigSq-" + (i + 1)).style("fill-opacity", .3);
    var div = d3.select('body').append("div")
        .attr("class", "tooltip").attr("id","fairtt").style("opacity", 0);

    div.transition().style("opacity", .8);
    div.html("Score: " + "N/A" + "<br>" + d.qdata)
        .style("left", (d3.event.pageX + 10) + "px")
        .style("top", (d3.event.pageY - 28) + "px");
}

function bopac(d, i) {
    d3.select("#insigSq-" + (i + 1)).style("fill-opacity", 1);
    d3.selectAll("#fairtt").remove();
}
