$("head").append('<style type="text/css">.submithere{ display: none;}</style>')
$("head").append('<style type="text/css">div.tooltip {' +
    'position: absolute;' +
    'padding: 2px;' +
    'font: 13px sans-serif;' +
    'background: black;' +
    'color:white;' +
    'border-radius:2px;' +
    'pointer-events: none;' +
    'max-width: 300px;' +
    '}</style>');
$("head").append('<style type="text/css">.insigCol{ text-align:center; }</style>')
$("head").append('<style type="text/css">#fairCol{ text-align:center; }</style>')
$("head").append('<style type="text/css">th{ font-weight:900; font-size:17px; padding-bottom:10px; }</style>')


$(document).ready(function () {
    $("table").append('<thead><th></th><th></th><th>Repository Name</th><th>Description</th><th id="fairCol">FAIRness Assessment</th>');
    var arr = [];

    var repoURLs = ['https://www.ebi.ac.uk/arrayexpress/', 'https://www.ncbi.nlm.nih.gov/bioproject/',
        'http://www.bmrb.wisc.edu/','http://cvrgrid.org/','http://www.cellimagelibrary.org/','https://www.ncbi.nlm.nih.gov/clinvar/',
        'https://datashare.nida.nih.gov/','https://clinicaltrials.gov','http://thedata.org/','http://www.datadryad.org',
        'http://www.chibi.ubc.ca/Gemma','http://www.ncbi.nlm.nih.gov/geo/','http://www.genenetwork.org/',
        'https://portal.gdc.cancer.gov/projects','https://gtexportal.org/home/','http://www.hgvs.org/dblist/glsdb.htm',
        'http://www.immport.org','http://www.icpsr.umich.edu/','http://www.metabolomicsworkbench.org/','http://phenome.jax.org/',
        'https://www.niddkrepository.org/','http://www.nitrc.org/ir/','https://sleepdata.org/','https://ndar.nih.gov/','http://neuromorpho.org/',
        'http://neurovault.org/','http://neurovault.org/collections/','http://neurovault.org/','http://www.nursa.org/','http://www.omicsdi.org/','http://openfmri.org/',
        'http://www.peptideatlas.org/','http://physionet.org/physiobank/','http://www.proteomexchange.org/','http://www.rcsb.org/pdb/',
        'http://rgd.mcw.edu/','http://www.nature.com/sdata/','https://www.ncbi.nlm.nih.gov/sra/','https://simtk.org/',
        'http://www.cancerimagingarchive.net/','http://www.ebi.ac.uk/pdbe/emdb/','http://www.gensat.org/retina.jsp',
        'https://www.ncbi.nlm.nih.gov/gap','http://www.uniprot.org/','https://www.vectorbase.org/','http://www.wormbase.org/',
        'http://medicine.yale.edu/keck/nida/yped.aspx',
        'Common Fund Repositories',
        'http://lincsportal.ccs.miami.edu/datasets/','http://www.roadmapepigenomics.org/',
        'DataCite',
        'https://clients.adaptivebiotech.com/immuneaccess/browse','https://www.ada.edu.au/','https://bils.se/','http://iaf.virtualbrain.org/xnat/',
        'http://www.cxidb.org/','http://crcns.org','http://databrary.org/','https://figshare.com/','http://www.neuroinf.de',
        'http://gigadb.org/','https://archive.data.jhu.edu','http://datacompass.lshtm.ac.uk/','http://wiley.biolucida.net/',
        'https://physionet.org/physiobank/database/','http://www.morphobank.org','http://www.nimh.nih.gov/','https://peerj.com/',
        'https://www.dza.de/fdz/deutscher-alterssurvey/deas-dokumentation/doi-deas.html','https://data.sbgrid.org/','https://www.ccdc.cam.ac.uk/',
        'https://www.thieme.de/','http://www.signaling-gateway.org/','https://dash.ucop.edu/stash','http://www.data-archive.ac.uk/','https://zenodo.org/'];
    var repoQ = JSON.parse(jQuery.ajax({
        async: false,
        url: 'http://54.175.203.110/fairshake/api/getQByType?',
        data: {
            'type':'Repository'
        }
    }).responseText);
    $("tbody").find('tr').each(function (index) {
        if (!(index == 47 || index == 50 )){
            var tempArr = [];
            var repoName = $(this).find('a').text();
            var repoURL = repoURLs[index];
            var repoDescrip = $(this).find('td').eq(3).text();
            tempArr.push(repoName, repoURL, repoDescrip);

            var repoAvg = JSON.parse(jQuery.ajax({
                async: false,
                url: 'http://54.175.203.110/fairshake/api/getAvg?',
                data: {
                    'url': repoURL
                }
            }).responseText);
            tempArr.push(repoAvg, repoQ);
            arr.push(tempArr);


            $(this).append('<td class="insigCol col-xs-1 ">'
                + '<div class="insignia"><div><form action="http://54.175.203.110/fairshake/redirectedFromExt" method="GET" target="_blank">'
                + '<input type="hidden" name="theName" value="' + repoName
                + '"><input type="hidden" name="theURL" value="' + repoURL
                + '"><input type="hidden" name="theDescrip" value="' + repoDescrip
                + '"><input type="hidden" name="theType" value="Repository">'
                + '<input type="hidden" name="theSrc" value="DataMed">'
                + '<div><label id="forInsig' + (index + 1) + '"><input type="submit" class="submithere"/></label></div></form></div></div></td>');

            if (repoAvg == 'None') {
                makeBlankInsig(repoQ, "#forInsig" + (index + 1), (index + 1));
            } else {
                makeInsig(repoAvg, repoQ, "#forInsig" + (index + 1), (index + 1));
            }

        } else {
            arr.push('Not repository');
        }
    });
});

function getSqDimension(qstns){
    sqnum=qstns.length;
    sqDimension=0;
    if(sqnum==4){
        sqDimension=20;
    } else if(sqnum==9){
        sqDimension=13;
    } else if(sqnum==16){
        sqDimension=10;
    } else if(sqnum==25){
        sqDimension=8;
    }
    return sqDimension;
}

function makeInsig(avg, qstns, position, insigIndex) {

    var scale = d3.scaleLinear().domain([-1, 1])
        .interpolate(d3.interpolateRgb)
        .range([d3.rgb(255, 0, 0), d3.rgb(0, 0, 255)]);

    var body = d3.select(position).append("svg").attr("width", 40).attr("height", 40);

    body.selectAll("rect.insig").data(getData(avg, qstns, insigIndex,'insig')).enter().append("rect").attr("class", "insig")
        .attr("id", function (d, i) {
            return "insigSq-" + d.insigIndex + "-" + (i + 1)
        })
        .attr("height",getSqDimension(qstns)).attr("width",getSqDimension(qstns))
        .attr("x", function (d) {
            return d.posx;
        }).attr("y", function (d) {
        return d.posy;
    }).style("fill", function (d) {
        return scale(d.numdata);
    }).style("stroke", "white").style("stroke-width", 1).style("shape-rendering", "crispEdges");

    body.selectAll("rect.btn").data(getData(avg, qstns, insigIndex,'btn')).enter().append("rect").attr("class", "btn")
        .attr("height",getSqDimension(qstns)).attr("width",getSqDimension(qstns))
        .attr("x", function (d) {
            return d.posx;
        }).attr("y", function (d) {
        return d.posy;
    }).style("fill-opacity", 0)
        .on("mouseover", opac)
        .on("mouseout", bopac)
    ;

}

function makeBlankInsig(qstns, position, insigIndex) {
    var body = d3.select(position).append("svg").attr("width", 40).attr("height", 40);

    body.selectAll("rect.insig").data(getBlankData(qstns, insigIndex)).enter().append("rect").attr("class", "insig")
        .attr("height",getSqDimension(qstns)).attr("width",getSqDimension(qstns))
        .attr("id", function (d, i) {
            return "insigSq-" + d.insigIndex + "-" + (i + 1)
        })
        .attr("x", function (d) {
            return d.posx;
        }).attr("y", function (d) {
        return d.posy;
    }).style("fill", "darkgray").style("stroke", "white").style("stroke-width", 1).style("shape-rendering", "crispEdges");

    body.selectAll("rect.btn").data(getBlankData(qstns, insigIndex)).enter().append("rect").attr("class", "btn")
        .attr("height",getSqDimension(qstns)).attr("width",getSqDimension(qstns))
        .attr("x", function (d) {
            return d.posx;
        }).attr("y", function (d) {
        return d.posy;
    }).style("fill-opacity", 0)
        .on("mouseover", opacBlank)
        .on("mouseout", bopac)
    ;
}

function getData(avg, qstns, insigIndex,testvar){
    sqnum=qstns.length;

    if (sqnum==4){
        return [{insigIndex: insigIndex, numdata: avg[0], qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {insigIndex: insigIndex, numdata: avg[1], qdata: "2. " + qstns[1], posx: 20, posy: 0},
            {insigIndex: insigIndex, numdata: avg[2], qdata: "3. " + qstns[2], posx: 0, posy: 20},
            {insigIndex: insigIndex, numdata: avg[3], qdata: "4. " + qstns[3], posx: 20, posy: 20}
        ]
    } else if (sqnum==9){
        return [{insigIndex: insigIndex, numdata: avg[0], qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {insigIndex: insigIndex, numdata: avg[1], qdata: "2. " + qstns[1], posx: 13, posy: 0},
            {insigIndex: insigIndex, numdata: avg[2], qdata: "3. " + qstns[2], posx: 26, posy: 0},
            {insigIndex: insigIndex, numdata: avg[3], qdata: "4. " + qstns[3], posx: 0, posy: 13},
            {insigIndex: insigIndex, numdata: avg[4], qdata: "5. " + qstns[4], posx: 13, posy: 13},
            {insigIndex: insigIndex, numdata: avg[5], qdata: "6. " + qstns[5], posx: 26, posy: 13},
            {insigIndex: insigIndex, numdata: avg[6], qdata: "7. " + qstns[6], posx: 0, posy: 26},
            {insigIndex: insigIndex, numdata: avg[7], qdata: "8. " + qstns[7], posx: 13, posy: 26},
            {insigIndex: insigIndex, numdata: avg[8], qdata: "9. " + qstns[8], posx: 26, posy: 26}
        ]
    } else if (sqnum==16){
        return [{insigIndex: insigIndex, numdata: avg[0], qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {insigIndex: insigIndex, numdata: avg[1], qdata: "2. " + qstns[1], posx: 10, posy: 0},
            {insigIndex: insigIndex, numdata: avg[2], qdata: "3. " + qstns[2], posx: 20, posy: 0},
            {insigIndex: insigIndex, numdata: avg[3], qdata: "4. " + qstns[3], posx: 30, posy: 0},
            {insigIndex: insigIndex, numdata: avg[4], qdata: "5. " + qstns[4], posx: 0, posy: 10},
            {insigIndex: insigIndex, numdata: avg[5], qdata: "6. " + qstns[5], posx: 10, posy: 10},
            {insigIndex: insigIndex, numdata: avg[6], qdata: "7. " + qstns[6], posx: 20, posy: 10},
            {insigIndex: insigIndex, numdata: avg[7], qdata: "8. " + qstns[7], posx: 30, posy: 10},
            {insigIndex: insigIndex, numdata: avg[8], qdata: "9. " + qstns[8], posx: 0, posy: 20},
            {insigIndex: insigIndex, numdata: avg[9], qdata: "10. " + qstns[9], posx: 10, posy: 20},
            {insigIndex: insigIndex, numdata: avg[10], qdata: "11. " + qstns[10], posx: 20, posy: 20},
            {insigIndex: insigIndex, numdata: avg[11], qdata: "12. " + qstns[11], posx: 30, posy: 20},
            {insigIndex: insigIndex, numdata: avg[12], qdata: "13. " + qstns[12], posx: 0, posy: 30},
            {insigIndex: insigIndex, numdata: avg[13], qdata: "14. " + qstns[13], posx: 10, posy: 30},
            {insigIndex: insigIndex, numdata: avg[14], qdata: "15. " + qstns[14], posx: 20, posy: 30},
            {insigIndex: insigIndex, numdata: avg[15], qdata: "16. " + qstns[15], posx: 30, posy: 30}
        ]
    } else if (sqnum==25){
        return [{insigIndex: insigIndex, numdata: avg[0], qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {insigIndex: insigIndex, numdata: avg[1], qdata: "2. " + qstns[1], posx: 8, posy: 0},
            {insigIndex: insigIndex, numdata: avg[2], qdata: "3. " + qstns[2], posx: 16, posy: 0},
            {insigIndex: insigIndex, numdata: avg[3], qdata: "4. " + qstns[3], posx: 24, posy: 0},
            {insigIndex: insigIndex, numdata: avg[4], qdata: "5. " + qstns[4], posx: 32, posy: 0},
            {insigIndex: insigIndex, numdata: avg[5], qdata: "6. " + qstns[5], posx: 0, posy: 8},
            {insigIndex: insigIndex, numdata: avg[6], qdata: "7. " + qstns[6], posx: 8, posy: 8},
            {insigIndex: insigIndex, numdata: avg[7], qdata: "8. " + qstns[7], posx: 16, posy: 8},
            {insigIndex: insigIndex, numdata: avg[8], qdata: "9. " + qstns[8], posx: 24, posy: 8},
            {insigIndex: insigIndex, numdata: avg[9], qdata: "10. " + qstns[9], posx: 32, posy: 8},
            {insigIndex: insigIndex, numdata: avg[10], qdata: "11. " + qstns[10], posx: 0, posy: 16},
            {insigIndex: insigIndex, numdata: avg[11], qdata: "12. " + qstns[11], posx: 8, posy: 16},
            {insigIndex: insigIndex, numdata: avg[12], qdata: "13. " + qstns[12], posx: 16, posy: 16},
            {insigIndex: insigIndex, numdata: avg[13], qdata: "14. " + qstns[13], posx: 24, posy: 16},
            {insigIndex: insigIndex, numdata: avg[14], qdata: "15. " + qstns[14], posx: 32, posy: 16},
            {insigIndex: insigIndex, numdata: avg[15], qdata: "16. " + qstns[15], posx: 0, posy: 24},
            {insigIndex: insigIndex, numdata: avg[16], qdata: "17. " + qstns[16], posx: 8, posy: 24},
            {insigIndex: insigIndex, numdata: avg[17], qdata: "18. " + qstns[17], posx: 16, posy: 24},
            {insigIndex: insigIndex, numdata: avg[18], qdata: "19. " + qstns[18], posx: 24, posy: 24},
            {insigIndex: insigIndex, numdata: avg[19], qdata: "20. " + qstns[19], posx: 32, posy: 24},
            {insigIndex: insigIndex, numdata: avg[20], qdata: "21. " + qstns[20], posx: 0, posy: 32},
            {insigIndex: insigIndex, numdata: avg[21], qdata: "22. " + qstns[21], posx: 8, posy: 32},
            {insigIndex: insigIndex, numdata: avg[22], qdata: "23. " + qstns[22], posx: 16, posy: 32},
            {insigIndex: insigIndex, numdata: avg[23], qdata: "24. " + qstns[23], posx: 24, posy: 32},
            {insigIndex: insigIndex, numdata: avg[24], qdata: "25. " + qstns[24], posx: 32, posy: 32},
        ]
    }
}

function getBlankData(qstns, insigIndex) {
    sqnum=qstns.length;

    if (sqnum==4){
        return [{insigIndex: insigIndex, qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {insigIndex: insigIndex, qdata: "2. " + qstns[1], posx: 20, posy: 0},
            {insigIndex: insigIndex, qdata: "3. " + qstns[2], posx: 0, posy: 20},
            {insigIndex: insigIndex, qdata: "4. " + qstns[3], posx: 20, posy: 20}
        ]
    } else if (sqnum==9){
        return [{insigIndex: insigIndex, qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {insigIndex: insigIndex, qdata: "2. " + qstns[1], posx: 13, posy: 0},
            {insigIndex: insigIndex, qdata: "3. " + qstns[2], posx: 26, posy: 0},
            {insigIndex: insigIndex, qdata: "4. " + qstns[3], posx: 0, posy: 13},
            {insigIndex: insigIndex, qdata: "5. " + qstns[4], posx: 13, posy: 13},
            {insigIndex: insigIndex, qdata: "6. " + qstns[5], posx: 26, posy: 13},
            {insigIndex: insigIndex, qdata: "7. " + qstns[6], posx: 0, posy: 26},
            {insigIndex: insigIndex, qdata: "8. " + qstns[7], posx: 13, posy: 26},
            {insigIndex: insigIndex, qdata: "9. " + qstns[8], posx: 26, posy: 26}
        ]
    } else if (sqnum==16){
        return [{insigIndex: insigIndex, qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {insigIndex: insigIndex, qdata: "2. " + qstns[1], posx: 10, posy: 0},
            {insigIndex: insigIndex, qdata: "3. " + qstns[2], posx: 20, posy: 0},
            {insigIndex: insigIndex, qdata: "4. " + qstns[3], posx: 30, posy: 0},
            {insigIndex: insigIndex, qdata: "5. " + qstns[4], posx: 0, posy: 10},
            {insigIndex: insigIndex, qdata: "6. " + qstns[5], posx: 10, posy: 10},
            {insigIndex: insigIndex, qdata: "7. " + qstns[6], posx: 20, posy: 10},
            {insigIndex: insigIndex, qdata: "8. " + qstns[7], posx: 30, posy: 10},
            {insigIndex: insigIndex, qdata: "9. " + qstns[8], posx: 0, posy: 20},
            {insigIndex: insigIndex, qdata: "10. " + qstns[9], posx: 10, posy: 20},
            {insigIndex: insigIndex, qdata: "11. " + qstns[10], posx: 20, posy: 20},
            {insigIndex: insigIndex, qdata: "12. " + qstns[11], posx: 30, posy: 20},
            {insigIndex: insigIndex, qdata: "13. " + qstns[12], posx: 0, posy: 30},
            {insigIndex: insigIndex, qdata: "14. " + qstns[13], posx: 10, posy: 30},
            {insigIndex: insigIndex, qdata: "15. " + qstns[14], posx: 20, posy: 30},
            {insigIndex: insigIndex, qdata: "16. " + qstns[15], posx: 30, posy: 30}
        ]
    } else if (sqnum==25){
        return [{insigIndex: insigIndex, qdata: "1. " + qstns[0], posx: 0, posy: 0},
            {insigIndex: insigIndex, qdata: "2. " + qstns[1], posx: 8, posy: 0},
            {insigIndex: insigIndex, qdata: "3. " + qstns[2], posx: 16, posy: 0},
            {insigIndex: insigIndex, qdata: "4. " + qstns[3], posx: 24, posy: 0},
            {insigIndex: insigIndex, qdata: "5. " + qstns[4], posx: 32, posy: 0},
            {insigIndex: insigIndex, qdata: "6. " + qstns[5], posx: 0, posy: 8},
            {insigIndex: insigIndex, qdata: "7. " + qstns[6], posx: 8, posy: 8},
            {insigIndex: insigIndex, qdata: "8. " + qstns[7], posx: 16, posy: 8},
            {insigIndex: insigIndex, qdata: "9. " + qstns[8], posx: 24, posy: 8},
            {insigIndex: insigIndex, qdata: "10. " + qstns[9], posx: 32, posy: 8},
            {insigIndex: insigIndex, qdata: "11. " + qstns[10], posx: 0, posy: 16},
            {insigIndex: insigIndex, qdata: "12. " + qstns[11], posx: 8, posy: 16},
            {insigIndex: insigIndex, qdata: "13. " + qstns[12], posx: 16, posy: 16},
            {insigIndex: insigIndex, qdata: "14. " + qstns[13], posx: 24, posy: 16},
            {insigIndex: insigIndex, qdata: "15. " + qstns[14], posx: 32, posy: 16},
            {insigIndex: insigIndex, qdata: "16. " + qstns[15], posx: 0, posy: 24},
            {insigIndex: insigIndex, qdata: "17. " + qstns[16], posx: 8, posy: 24},
            {insigIndex: insigIndex, qdata: "18. " + qstns[17], posx: 16, posy: 24},
            {insigIndex: insigIndex, qdata: "19. " + qstns[18], posx: 24, posy: 24},
            {insigIndex: insigIndex, qdata: "20. " + qstns[19], posx: 32, posy: 24},
            {insigIndex: insigIndex, qdata: "21. " + qstns[20], posx: 0, posy: 32},
            {insigIndex: insigIndex, qdata: "22. " + qstns[21], posx: 8, posy: 32},
            {insigIndex: insigIndex, qdata: "23. " + qstns[22], posx: 16, posy: 32},
            {insigIndex: insigIndex, qdata: "24. " + qstns[23], posx: 24, posy: 32},
            {insigIndex: insigIndex, qdata: "25. " + qstns[24], posx: 32, posy: 32},
        ]
    }
}


function roundTwo(num) {
    return +(Math.round(num + "e+2") + "e-2");
}

function opac(d, i) {
    d3.select("#insigSq-" + d.insigIndex + "-" + (i + 1)).style("fill-opacity", .3);
    var div = d3.select(this.parentNode.parentNode).append("div")
        .attr("class", "tooltip").attr("id","fairtt").style("opacity", 0);

    div.transition().style("opacity", .8);
    div.html("Score: " + roundTwo(d.numdata) + "<br>" + d.qdata)
        .style("left", (d3.event.pageX + 10) + "px")
        .style("top", (d3.event.pageY - 28) + "px");
}

function opacBlank(d, i) {
    d3.select("#insigSq-" + d.insigIndex + "-" + (i + 1)).style("fill-opacity", .3);
    var div = d3.select(this.parentNode.parentNode).append("div")
        .attr("class", "tooltip").attr("id","fairtt").style("opacity", 0);

    div.transition().style("opacity", .8);
    div.html("Score: " + 'N/A' + "<br>" + d.qdata)
        .style("left", (d3.event.pageX + 10) + "px")
        .style("top", (d3.event.pageY - 28) + "px");
}

function bopac(d, i) {
    d3.select("#insigSq-" + d.insigIndex + "-" + (i + 1)).style("fill-opacity", 1);
    d3.selectAll("#fairtt").remove();
}